<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMailable;


Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::post('/upload', 'PostsController@fun')->name('upload');

Route::get('/upload', 'PostsController@index');


Route::get('/all', function() {
    return view('user_pages.all_imgs');
});

Route::get('sample', function () {
    return view('sample');
});


Route::get('login_users', 'loginController@getLogIn');
Route::post('login_users', 'loginController@postLogIn');

// 
Route::get('forgot_pass', 'loginController@getForgotPass');
Route::post('forgot_pass', 'loginController@postForgotPass');
Route::post('forgot_pass1', 'loginController@postResetPass');

Route::get('forgotPassMail','loginController@getResetPass');


Route::get('sign_up_users','loginController@getSignUp');
Route::post('sign_up_users','loginController@postSignUp');


Route::get('mail', 'loginController@mail');


Route::get('checkMail', 'loginController@checkMail');






