<?php

namespace App\Http\Controllers;

use App\captains;
use Illuminate\Http\Request;

class CaptainsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\captains  $captains
     * @return \Illuminate\Http\Response
     */
    public function show(captains $captains)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\captains  $captains
     * @return \Illuminate\Http\Response
     */
    public function edit(captains $captains)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\captains  $captains
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, captains $captains)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\captains  $captains
     * @return \Illuminate\Http\Response
     */
    public function destroy(captains $captains)
    {
        //
    }
}
