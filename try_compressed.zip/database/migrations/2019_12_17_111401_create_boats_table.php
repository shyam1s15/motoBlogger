<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBoatsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('boats', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->char('boat_name',30);
            $table->string('boat_description',400)->nullable();
            $table->integer('total_members')->nullable();
            $table->integer('total_devs')->nullable();
            $table->smallInteger('boat_level')->nullable();
            $table->integer('total_posts');
            $table->char('type',15);
            $table->integer('captain_id');//joins here
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('boats');
    }
}
