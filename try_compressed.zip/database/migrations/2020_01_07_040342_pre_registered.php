<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class PreRegistered extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tempStudents', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->char('email',40);
            $table->char('password',200);
            $table->char('address',100);
            $table->char('address2',100);
            $table->char('city',30);
            $table->char('state',50);
            $table->char('zipcode',10);
            $table->char('hashCode',100)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tempStudents');
    }
}
