<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\boats;
use Faker\Generator as Faker;

$factory->define(boats::class, function (Faker $faker) {
    return [
        //
    ];
});
