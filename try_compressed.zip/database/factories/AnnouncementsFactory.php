<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\announcements;
use Faker\Generator as Faker;

$factory->define(announcements::class, function (Faker $faker) {
    return [
        //
    ];
});
