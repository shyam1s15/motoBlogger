<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\developers;
use Faker\Generator as Faker;

$factory->define(developers::class, function (Faker $faker) {
    return [
        //
    ];
});
