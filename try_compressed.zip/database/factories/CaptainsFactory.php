<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\captains;
use Faker\Generator as Faker;

$factory->define(captains::class, function (Faker $faker) {
    return [
        //
    ];
});
