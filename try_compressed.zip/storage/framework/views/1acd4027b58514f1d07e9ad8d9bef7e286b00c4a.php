<style>
  .box{
      margin-left: 300px;
      border: 2px solid red;
      padding: 20px;
      width: 100%;
}
.link{
    margin-left: 20px;
}
</style>
<?php $__env->startSection('content'); ?>

<div class="package container-fluid">
  <div class="box">
    <?php if(\Session::has('Bad_Password')): ?>
        <h2><?php echo e(\Session::get('Bad_Password')); ?></h2>
    <?php endif; ?>
    <form autocomplete="off" action="forgot_pass1" method="post">
      <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="inputEmail4">Change password for : <?php echo e($mail); ?></label>
        </div>
        <div class="form-group">
          <label for="inputPassword1">Password</label>
          <input type="password" class="form-control" id="inputPassword4abc" name="password" autocomplete="new-password" required>
          <label for="inputPassword1">confirm-Password</label>
          <input type="confirm-password" class="form-control" id="inputPassword5abc" name="confirm-password" autocomplete="new-password" required>
            <input type="hidden" name="mail" value=<?php echo e($mail); ?>>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>   
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shyam/Desktop/old folders/laravel/try2/resources/views/layouts/logups/change_pass_file.blade.php ENDPATH**/ ?>