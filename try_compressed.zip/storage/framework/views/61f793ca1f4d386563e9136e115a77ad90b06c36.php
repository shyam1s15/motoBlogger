<style>
  .box{
      margin-left: 300px;
      border: 2px solid red;
      padding: 20px;
      width: 100%;
}
.link{
    margin-left: 20px;
}
</style>
<?php $__env->startSection('content'); ?>

<div class="package container-fluid">
  <div class="box">
    <?php if(\Session::has('user_not_exists')): ?>
        <h2><?php echo e(\Session::get('user_not_exists')); ?></h2>
    <?php endif; ?>
    <form autocomplete="off" action="login_users" method="post">
      <?php echo e(csrf_field()); ?>

        <div class="form-group">
          <label for="inputEmail4">Email address</label>
          <input type="email" class="form-control" id="inputEmail4" aria-describedby="emailHelp" name="email" autocomplete="new-password" required>
          <small id="emailHelp" class="form-text text-muted">We will ll never share your email with anyone else.</small>
        </div>
        <div class="form-group">
          <label for="inputPassword1">Password</label>
          <input type="password" class="form-control" id="inputPassword4abc" name="password" autocomplete="new-password" required>
        </div>
        <div class="form-group form-check">
          <input type="checkbox" class="form-check-input" id="exampleCheck1" name="cbLogout">
          <label class="form-check-label" for="exampleCheck1">Logout at closing tabs</label>
          <a href="forgot_pass" class="link">forgot password</a>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>   
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shyam/Desktop/old folders/laravel/try2/resources/views/layouts/logups/login_users.blade.php ENDPATH**/ ?>