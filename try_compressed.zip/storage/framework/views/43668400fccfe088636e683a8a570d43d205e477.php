<?php $__env->startSection('content'); ?>

<div class="content">
    <h1><?php echo e($details['title']); ?></h1>
    <h2><?php echo e($details['body']); ?></h2>

    <h3>chal be baap ko mat sikha</h3>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shyam/Desktop/laravel/try2/resources/views/layouts/mailViews/name.blade.php ENDPATH**/ ?>