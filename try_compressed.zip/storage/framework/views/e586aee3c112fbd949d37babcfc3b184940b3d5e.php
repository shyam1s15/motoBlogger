<style>
  .box{
      margin-left: 300px;
      border: 2px solid red;
      padding: 20px;
      width: 100%;
}
.link{
    margin-left: 20px;
}
</style>
<?php $__env->startSection('content'); ?>

<div class="package container-fluid">
  <div class="box">
    
    <form autocomplete="off" action="forgot_pass" method="post">
      <?php echo e(csrf_field()); ?>

      <?php if(\Session::has("mail_not_exists")): ?>
          <h3><?php echo e(\Session::get("mail_not_exists")); ?></h3>
      <?php endif; ?>
        <div class="form-group">
          <label for="inputEmail4">Mail will be sent to following Email address</label>
          <input type="email" class="form-control" id="inputEmail4" aria-describedby="emailHelp" name="email" autocomplete="new-password" required>
          <small id="emailHelp" class="form-text text-muted">We will ll never share your email with anyone else.</small>
        </div>
        
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>   
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shyam/Desktop/old folders/laravel/try2/resources/views/layouts/logups/forgot_pass.blade.php ENDPATH**/ ?>