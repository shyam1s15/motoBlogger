<?php $__env->startSection('content'); ?>
    <div class="box">
        <h2>fail sign up page</h2>
        <?php if($failed == "Sign Up failed"): ?>
            <h1>sorry to say the sign up has been failed please try again later</h1>
        <?php endif; ?>

        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($item); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shyam/Desktop/old folders/laravel/try2/resources/views/layouts/logups/failed_signup.blade.php ENDPATH**/ ?>