<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    

    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

<style>
body {
  font-family: "Lato", sans-serif;
  background-color: black;
  color: white
}
span{
    margin-left: 10px;
    margin-top: 10px;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
  text-align:center;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;

}

.sidenav a:hover{
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}
.nopadding > div[class^="col-"] {
    padding-right: 0;
    padding-left: 0;
}

@media  screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
</head>

<body>

<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">About</a>
  <a href="#">Services</a>
  <a href="#">Clients</a>
  <a href="#">Contact</a>
  <a href="#">login</a>
  <a href="#">SIgn up</a>
  <a href="#"></a>

</div>

<div class="container-fluid">
<div class="row nopadding">
    
    <div class="col-md-2">
    <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; suit Up</span>
    
    </div>
    <div class="col-md-2">
        <button type="button" class="btn btn-light" style="width:100%">Clan: Light</button>
    </div>
    
    
    <div class="input-group mb-3 col-md-6">
        <input type="text" class="form-control" placeholder="(#boat, @user)" aria-label="Recipient's username" aria-describedby="button-addon2">
        <div class="input-group-append">
          <button class="btn btn-outline-secondary" type="submit" id="button-addon2">&#128269; Search</button>
        </div>
    </div>
    
    <div class="col-md-2">
        <button type="button" class="btn btn-danger" style="width:100%">&#10084; create boat</button>
    </div>


<main class="py-4">

        <?php echo $__env->yieldContent('content'); ?>
</main>
</div>
</div>
<script>
    function openNav() {
  document.getElementById("mySidenav").style.width = "20%";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
   
</body>
</html> 
<?php /**PATH /home/shyam/Desktop/laravel/try2/resources/views/layouts/master_layouts/base.blade.php ENDPATH**/ ?>