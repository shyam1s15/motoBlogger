


<div class="content">
    <h1><?php echo e($details['title']); ?></h1>
    <h2><?php echo e($details['body']); ?></h2>
    <h3><?php echo e($details['link']); ?></h3>
</div>
    
<?php /**PATH /home/shyam/Desktop/old folders/laravel/try2/resources/views/layouts/mailViews/name.blade.php ENDPATH**/ ?>