<?php $__env->startSection('content'); ?>
    <h1>congo for sign up</h1>
       
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shyam/Desktop/old folders/laravel/try2/resources/views/layouts/logups/success_logged.blade.php ENDPATH**/ ?>