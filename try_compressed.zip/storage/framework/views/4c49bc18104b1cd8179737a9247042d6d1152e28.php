<?php $__env->startSection('content'); ?>
    <div class="box">
        <?php if($result == "Sign Up failed"): ?>
            <h1>sorry to say the sign up has been failed please try again later</h1>
        <?php endif; ?>

        <?php if($result == "Signed Up"): ?>
            <h1>congo for sign up</h1>
        <?php endif; ?>

        <?php if($result == "Pre Signed Up"): ?>
            <h1>Hello User Good Day to you, Please check your mail</h1>
        <?php endif; ?>
        
        <?php if($result == "logged in"): ?>
            <h1>Hii user you are successfully logged in</h1>
        <?php endif; ?>
        
        <?php if($result == "checkMail for pass"): ?>
            <h1>Sorry for incoviniency user please reset your password using your mail</h1>
        <?php endif; ?>

        <?php if($result == "success_pass_change"): ?>
            <h1>COngratulations user your password has been changed</h1>
        <?php endif; ?>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shyam/Desktop/old folders/laravel/try2/resources/views/layouts/logups/result_of_signup_login.blade.php ENDPATH**/ ?>