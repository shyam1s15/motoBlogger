{{-- @extends('layouts.master_layouts.base') --}}
{{-- @section('content') --}}

<div class="content">
    <h1>{{ $details['title'] }}</h1>
    <h2>{{ $details['body'] }}</h2>
    <h3>{{ $details['link'] }}</h3>
</div>
    
{{-- @endsection --}}