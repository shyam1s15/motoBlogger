@extends('layouts.master_layouts.base')

@section('content')

@endsection
